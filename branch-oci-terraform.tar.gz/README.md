# VenueShift: OCI Deployment
Terraform-based deployment using Oracle Cloud Infrastructure.