# VenueShift: Multi-Cloud (Firebase + Supabase)
Frontend hosted on Vercel, backendless using Firebase and Supabase.